import { Component } from '@angular/core';

@Component({
  selector: 'nutrition',
  templateUrl: './nutrition.component.html',
  styleUrl: './nutrition.component.css'
})
export class NutritionComponent {

}
