module.exports = {
  content: [
    "./src/**/*.{html,ts}", // Adjust this path as needed
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
